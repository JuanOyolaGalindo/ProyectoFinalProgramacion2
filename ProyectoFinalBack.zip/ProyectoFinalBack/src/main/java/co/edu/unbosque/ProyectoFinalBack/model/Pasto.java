package co.edu.unbosque.ProyectoFinalBack.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Pasto {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String producto;
	private Integer costoproducto;
	private Integer precioventa;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProducto() {
		return producto;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	public Integer getCostoproducto() {
		return costoproducto;
	}
	public void setCostoproducto(Integer costoproducto) {
		this.costoproducto = costoproducto;
	}
	public Integer getPrecioventa() {
		return precioventa;
	}
	public void setPrecioventa(Integer precioventa) {
		this.precioventa = precioventa;
	}
}
