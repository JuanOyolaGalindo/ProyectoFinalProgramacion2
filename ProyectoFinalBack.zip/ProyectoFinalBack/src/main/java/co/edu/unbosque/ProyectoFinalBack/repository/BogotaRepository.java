 package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinalBack.model.Bogota;


public interface BogotaRepository extends CrudRepository<Bogota,Integer>{

	public Optional<Bogota> findById(Integer id);
	
	public List<Bogota> findAll();
	
	public void deleteById(Integer id);
}
