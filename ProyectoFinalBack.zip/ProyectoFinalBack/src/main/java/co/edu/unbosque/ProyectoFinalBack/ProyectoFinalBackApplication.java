package co.edu.unbosque.ProyectoFinalBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalBackApplication.class, args);
	}

}
