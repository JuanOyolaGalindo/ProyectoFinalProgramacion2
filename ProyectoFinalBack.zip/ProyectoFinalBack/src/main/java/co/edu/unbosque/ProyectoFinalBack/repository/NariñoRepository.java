package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinalBack.model.Nariño;

public interface NariñoRepository extends CrudRepository<Nariño,Integer>{
	public Optional<Nariño> findById(Integer id);

	public List<Nariño> findAll();

	public void deleteById(Integer id);
}
