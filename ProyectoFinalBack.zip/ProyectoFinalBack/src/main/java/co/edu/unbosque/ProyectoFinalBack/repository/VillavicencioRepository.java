package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinalBack.model.Villavicencio;

public interface VillavicencioRepository extends CrudRepository<Villavicencio, Integer>{
	public Optional<Villavicencio> findById(Integer id);

	public List<Villavicencio> findAll();

	public void deleteById(Integer id);
}
