package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import co.edu.unbosque.ProyectoFinalBack.model.Caracas;

public interface CaracasRepository extends CrudRepository<Caracas, Integer> {

	public Optional<Caracas> findById(Integer id);

	public List<Caracas> findAll();

	public void deleteById(Integer id);
}
