package co.edu.unbosque.ProyectoFinalBack.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.ProyectoFinalBack.model.Colaborador;
import co.edu.unbosque.ProyectoFinalBack.repository.ColaboradorRepository;
import jakarta.transaction.Transactional;
@Transactional
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api")
public class ColaboradorController {
	@Autowired
	private ColaboradorRepository cores;

	@PostMapping("/colaborador")
	public ResponseEntity<String> agregarProducto(@RequestParam String nombre, @RequestParam String cedula, @RequestParam Integer edad, @RequestParam String sucursal, @RequestParam String cargo) {
		Colaborador temp = new Colaborador();
		temp.setNombre(nombre);
		temp.setCedula(cedula);
		temp.setCargo(cargo);
		temp.setEdad(edad);
		temp.setSucursal(sucursal);
		cores.save(temp);
		return ResponseEntity.status(HttpStatus.CREATED).body("Colaborador agregado con exito: 201");
	}

	@GetMapping("/colaborador")
	public ResponseEntity<List<Colaborador>> traerTodo() {
		List<Colaborador> lista = cores.findAll();
		if (lista.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
		return ResponseEntity.status(HttpStatus.OK).body(lista);
	}

	@GetMapping("/colaborador/{id}")
	public ResponseEntity<Optional<Colaborador>> mostrarPorID(@RequestParam Integer id) {
		Optional<Colaborador> dato = cores.findById(id);
		if (dato.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
		return ResponseEntity.status(HttpStatus.OK).body(dato);
	}

	@DeleteMapping("/colaborador/{id}")
	public ResponseEntity<String> eliminarPorID(@RequestParam Integer id) {
		Optional<Colaborador> dato = cores.findById(id);
		if (dato.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se pudo eliminar el colaborador");
		}
		cores.deleteById(id);
		return ResponseEntity.status(HttpStatus.OK).body("Eliminado exitosamente");
	}

	@PutMapping("/colaborador/{id}")
	public ResponseEntity<String> actualizar(@RequestParam Integer id, @RequestParam String nombre, @RequestParam String cedula, @RequestParam Integer edad, @RequestParam String sucursal, @RequestParam String cargo) {		
		Optional<Colaborador> dato = cores.findById(id);
		if (dato.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se pudo actualizar el producto");
		}
		Colaborador temp = dato.get();
		temp.setNombre(nombre);
		temp.setCedula(cedula);
		temp.setCargo(cargo);
		temp.setEdad(edad);
		temp.setSucursal(sucursal);
		cores.save(temp);
		return ResponseEntity.status(HttpStatus.OK).body("Colaborador actualizado exitosamente");
	}
}
