package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinalBack.model.Colaborador;

public interface ColaboradorRepository extends CrudRepository<Colaborador, Integer>{
	
	public Optional<Colaborador> findById(Integer id);
	
	public List<Colaborador> findAll();
	
	public void deleteById(Integer id);
}
