package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinalBack.model.Pasto;

public interface PastoRepository extends CrudRepository<Pasto,Integer>{
	public Optional<Pasto> findById(Integer id);

	public List<Pasto> findAll();

	public void deleteById(Integer id);
}
