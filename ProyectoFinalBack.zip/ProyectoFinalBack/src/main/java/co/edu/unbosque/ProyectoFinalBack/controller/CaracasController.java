package co.edu.unbosque.ProyectoFinalBack.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.ProyectoFinalBack.model.Bogota;
import co.edu.unbosque.ProyectoFinalBack.model.Caracas;
import co.edu.unbosque.ProyectoFinalBack.model.Villavicencio;
import co.edu.unbosque.ProyectoFinalBack.repository.CaracasRepository;
import jakarta.transaction.Transactional;

@Transactional
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api")
public class CaracasController {
	@Autowired
	private CaracasRepository cares;

	@PostMapping("/caracas")
	public ResponseEntity<String> agregarProducto(@RequestParam String producto, @RequestParam Integer costoproducto, @RequestParam Integer precioventa) {
		Caracas temp = new Caracas();
		temp.setProducto(producto);
		temp.setCostoproducto(costoproducto);
		temp.setPrecioventa(precioventa);
		cares.save(temp);
		return ResponseEntity.status(HttpStatus.CREATED).body("Producto agregado con exito: 201");
	}

	@GetMapping("/caracas")
	public ResponseEntity<List<Caracas>> traerTodo() {
		List<Caracas> lista = cares.findAll();
		if (lista.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
		return ResponseEntity.status(HttpStatus.OK).body(lista);
	}

	@GetMapping("/caracas/{id}")
	public ResponseEntity<Optional<Caracas>> mostrarPorID(@RequestParam Integer id) {
		Optional<Caracas> dato = cares.findById(id);
		if (dato.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
		return ResponseEntity.status(HttpStatus.OK).body(dato);
	}

	@DeleteMapping("/caracas/{id}")
	public ResponseEntity<String> eliminarPorID(@RequestParam Integer id) {
		Optional<Caracas> dato = cares.findById(id);
		if (dato.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se pudo eliminar el dato");
		}
		cares.deleteById(id);
		return ResponseEntity.status(HttpStatus.OK).body("Eliminado exitosamente");
	}

	@PutMapping("/caracas/{id}")
	public ResponseEntity<String> actualizar(@RequestParam Integer id, @RequestParam String producto, @RequestParam Integer costoproducto, @RequestParam Integer precioventa) {
		
		Optional<Caracas> dato = cares.findById(id);
		if (dato.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se pudo actualizar el producto");
		}
		Caracas temp = dato.get();
		temp.setProducto(producto);
		temp.setCostoproducto(costoproducto);
		temp.setPrecioventa(precioventa);
		cares.save(temp);
		return ResponseEntity.status(HttpStatus.OK).body("Producto actualizado exitosamente");
	}
	@GetMapping("/caracas/ganancia")
	public ResponseEntity<Double> mostrarPorcentajeGananciaInventario() {
		List<Caracas> lista = cares.findAll();
		double porcentajeganancia = 0;
		int preciobase = 0;
		int precioventa = 0;
		if (lista.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
		for (int i = 0; i < lista.size(); i++) {
			preciobase = lista.get(i).getCostoproducto();
			precioventa = lista.get(i).getPrecioventa();

		}
		porcentajeganancia = (100 * precioventa) / preciobase;
		return ResponseEntity.status(HttpStatus.OK).body(porcentajeganancia);
	}
}
