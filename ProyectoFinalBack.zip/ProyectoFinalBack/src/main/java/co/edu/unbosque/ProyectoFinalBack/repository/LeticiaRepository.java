package co.edu.unbosque.ProyectoFinalBack.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinalBack.model.Leticia;

public interface LeticiaRepository extends CrudRepository<Leticia, Integer>{
	
	public Optional<Leticia> findById(Integer id);

	public List<Leticia> findAll();

	public void deleteById(Integer id);
}
