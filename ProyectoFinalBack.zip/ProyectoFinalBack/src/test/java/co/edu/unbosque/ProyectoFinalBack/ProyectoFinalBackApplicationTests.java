package co.edu.unbosque.ProyectoFinalBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
